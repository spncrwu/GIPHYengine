document.addEventListener('DOMContentLoaded', (event) => {

    /*  API Request */
    function get_results() {

        var url = 'http://tv.giphy.com/v1/gifs/tv?api_key=CW27AW0nlp5u0&tag=giphytv';
// AJAX Request
        var GiphyAJAXCall = new XMLHttpRequest();
        GiphyAJAXCall.open('GET', url);
        GiphyAJAXCall.send();

        GiphyAJAXCall.addEventListener('load', function (e) {

            var data = e.target.response;
            pushToDOM(data);

        });
    }

    /* add image to page */
    function pushToDOM(input) {
        var container = document.querySelector(".js-container");
        container.innerHTML = '';
        var response = JSON.parse(input);
        var src = response.data.image_original_url;
        container.innerHTML += "<img src=\"" + src + "\" class=\"container-image\">";
    }

    /* Image change timer */
    var timerTime = 5000; 

    setInterval(timerFunction, timerTime);

    function timerFunction() {
        get_results();
    }

    get_results();

});


